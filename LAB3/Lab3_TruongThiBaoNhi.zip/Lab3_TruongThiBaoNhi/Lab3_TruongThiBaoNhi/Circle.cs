﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_TruongThiBaoNhi
{
    class Circle
    {
        //khai bao thuoc tinh
        public float radius { get; set; }
        //khoi tao khong tham so
        public Circle()
        {
            radius = 1;
        }
        //khoi tao co tham so
        public Circle(float r)
        {
            this.radius = r;
        }
        //tinh chu vi duong tron
        public double Cal_Perimeter()
        {
            return 2 * Math.PI * radius;
        }
        //tinh dien tich duong tron
        public double Cal_Area()
        {
            return Math.PI * radius * radius;
        }
        //in ra man hinh thong tin
        public void Info()
        {
            Console.WriteLine($"Ban kinh: {radius}\n Chu vi duong tron: {Cal_Perimeter()}\n Dien tich duong tron: {Cal_Area()}");
        }
        //toan tu cong so thuc voi dien tich cua doi tuong circle
        public static double operator +(double d, Circle c)
        {
            return d + c.Cal_Area();
        }
        //so sanh chu vi giua 2 doi tuong circle
        public static bool operator <(Circle c1, Circle c2)
        {
            return c1.Cal_Perimeter() < c2.Cal_Perimeter();
        }
        public static bool operator >(Circle c1, Circle c2)
        {
            return c1.Cal_Perimeter() > c2.Cal_Perimeter();
        }

    }
    class ListCircle
    {
        int n;
        Circle[] ls;
        //nhap n hinh tron
        public void Nhap()
        {
            Console.Write("Nhap so hinh tron: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 2 || n >= 30)
            {
                Console.Write("Nhap lai!!!!");
            }
            ls = new Circle[n];
            for (int i = 0; i < n; i++)
            {
                float r;
                Console.Write("Nhap ban kinh duong tron: ");
                while (!float.TryParse(Console.ReadLine(), out r) || r <= 0)
                {
                    Console.Write("Nhap lai coi!!!!!!!!");
                }
                ls[i] = new Circle(r);
            }
        }
        public void OutPut_List()
        {
            foreach (Circle c in ls)
                c.Info();
        }
        //tinh tong dien tich n Circle
        public double Sum_Area()
        {
            double s = 0;
            foreach (Circle c in ls)
                s = s + c; // c.Cal_Area();
            return s;
        }
        //tim duong tron co chu vi lon nhat
        public Circle Find_Max()
        {
            Circle max = new Circle();
            max = ls[0];//gia su phan tu dau tien la lon nhat
            for (int i = 1; i < ls.Length; i++)
                if (max < ls[i]) //max.Cal_Perimeter() < ds[i].Cal_Perimeter()
                    max = ls[i];
            return max;
        }

    }
}
