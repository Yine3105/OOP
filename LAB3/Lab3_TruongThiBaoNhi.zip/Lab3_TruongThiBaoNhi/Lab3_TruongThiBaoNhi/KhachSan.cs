﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_TruongThiBaoNhi
{
    class PhieuLuuTru
    {
        // Các thuộc tính
        public int soPhong { get; set; }
        public string hoTenKhach { get; set; }
        public DateTime ngayDen { get; set; }
        public DateTime ngayDi { get; set; }
        public int loaiPhong { get; set; }
        public static double giaSan = 300;  // Giá sàn dùng chung

        // Các phương thức

        // Khởi tạo không tham số
        public PhieuLuuTru()
        {
            soPhong = 0;
            hoTenKhach = "";
            ngayDen = DateTime.Now;
            ngayDi = DateTime.Now;
            loaiPhong = 1;
        }

        // Khởi tạo có tham số
        public PhieuLuuTru(int soPhong, string hoTenKhach, DateTime ngayDen, DateTime ngayDi, int loaiPhong)
        {
            this.soPhong = soPhong;
            this.hoTenKhach = hoTenKhach;
            this.ngayDen = ngayDen;
            this.ngayDi = ngayDi;
            this.loaiPhong = loaiPhong;
        }

        // Nhập thông tin phiếu lưu trú
        public void NhapThongTin()
        {
            Console.Write("Nhap so phong: ");
            soPhong = int.Parse(Console.ReadLine());
            Console.Write("Nhap ho ten khach: ");
            hoTenKhach = Console.ReadLine();
            Console.Write("Nhap ngay den (dd/mm/yyyy): ");
            ngayDen = DateTime.Parse(Console.ReadLine());
            Console.Write("Nhap ngay di (dd/mm/yyyy): ");
            ngayDi = DateTime.Parse(Console.ReadLine());
            Console.Write("Nhap loai phong (1, 2, 3): ");
            loaiPhong = int.Parse(Console.ReadLine());
        }

        // Tính tiền phòng
        public double TinhTienPhong()
        {
            int soNgayO = (ngayDi - ngayDen).Days;
            if (soNgayO == 0)
                soNgayO = 1;

            double giaPhong;
            if (loaiPhong == 1)
                giaPhong = 1.5 * giaSan;
            else if (loaiPhong == 2)
                giaPhong = 1.3 * giaSan;
            else
                giaPhong = giaSan;

            return soNgayO * giaPhong;
        }

        // Xuất thông tin phiếu lưu trú
        public void XuatThongTin()
        {
            Console.WriteLine("So phong: " + soPhong);
            Console.WriteLine("Ho ten khach: " + hoTenKhach);
            Console.WriteLine("So ngay o: " + (ngayDi - ngayDen).Days);
            Console.WriteLine("Gia phong: " + (loaiPhong == 1 ? 1.5 * giaSan : loaiPhong == 2 ? 1.3 * giaSan : giaSan));
            Console.WriteLine("Tien phong: " + TinhTienPhong());
        }

        // Toán tử so sánh < (so sánh số ngày ở)
        public static bool operator <(PhieuLuuTru p1, PhieuLuuTru p2)
        {
            return (p1.ngayDi - p1.ngayDen).Days < (p2.ngayDi - p2.ngayDen).Days;
        }

        public static bool operator >(PhieuLuuTru p1, PhieuLuuTru p2)
        {
            return (p1.ngayDi - p1.ngayDen).Days > (p2.ngayDi - p2.ngayDen).Days;
        }

        // Toán tử + (cộng một số với tiền phòng)
        public static double operator +(double tien, PhieuLuuTru p)
        {
            return tien + p.TinhTienPhong();
        }
    }

    class QuanLyPhieuLuuTru
    {
        private List<PhieuLuuTru> danhSachPhieu;

        public QuanLyPhieuLuuTru()
        {
            danhSachPhieu = new List<PhieuLuuTru>();
        }

        public void NhapDanhSachPhieu()
        {
            int n;
            // Nhập số lượng phiếu lưu trú
            Console.Write("Nhap so luong phieu luu tru (1 < n < 30): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 1 || n >= 30)
            {
                Console.Write("Nhap lai (1 < n < 30): ");
            }

            // Nhập thông tin n phiếu lưu trú
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nNhap thong tin phieu luu tru thu " + (i + 1) + ":");
                PhieuLuuTru phieu = new PhieuLuuTru();
                phieu.NhapThongTin();
                danhSachPhieu.Add(phieu);
            }
        }

        public void XuatDanhSachPhieuTheoSoNgayO()
        {
            Console.WriteLine("\n\nDanh sach phieu luu tru (giam dan theo so ngay o):");
            danhSachPhieu.Sort((p1, p2) => (p2.ngayDi - p2.ngayDen).Days.CompareTo((p1.ngayDi - p1.ngayDen).Days)); //Sử dụng toán tử > để sắp xếp giảm dần
            foreach (PhieuLuuTru phieu in danhSachPhieu)
            {
                phieu.XuatThongTin();
                Console.WriteLine("--------------------");
            }
        }

        public void DemPhieuLuuTruQuy4Nam2024()
        {
            int count = 0;
            foreach (PhieuLuuTru phieu in danhSachPhieu)
            {
                if (phieu.ngayDen.Year == 2024 && phieu.ngayDen.Month >= 10 && phieu.ngayDen.Month <= 12)
                {
                    count++;
                }
            }
            Console.WriteLine("\nSo luong phieu luu tru trong quy 4 nam 2024: " + count);
        }

        public void TinhVaInTienPhongTrungBinh()
        {
            double tongTienPhong = 0;
            foreach (PhieuLuuTru phieu in danhSachPhieu)
            {
                tongTienPhong = tongTienPhong + phieu; // Sử dụng toán tử +
            }
            double trungBinhTienPhong = tongTienPhong / danhSachPhieu.Count;
            Console.WriteLine("\nTien phong trung binh cua " + danhSachPhieu.Count + " phieu luu tru: " + trungBinhTienPhong);
        }
    }
}