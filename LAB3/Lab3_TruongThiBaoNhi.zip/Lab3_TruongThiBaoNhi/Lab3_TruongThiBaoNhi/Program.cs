﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_TruongThiBaoNhi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            int choice;
            do
            {
                Console.WriteLine("1. Phan So");
                Console.WriteLine("2. Duong Tron");
                Console.WriteLine("3. Hoc Phan");
                Console.WriteLine("4. Khach San");
                Console.WriteLine("5. Adult");
                Console.WriteLine("6. Hoc Vien");
                Console.WriteLine("0. Thoat");
                Console.Write("Nhap lua chon cua ban: ");
                while (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.Write("Nhap lai lua chon (la mot so nguyen): ");
                }

                switch (choice)
                {
                    case 1:
                        PhanSo();
                        break;
                    case 2:
                        Circle();
                        break;
                    case 3:
                        HocPhan();
                        break;
                    case 4:
                        KhachSan();
                        break;
                    case 5:
                        Adult();
                        break;
                    case 6:
                        HocVien();
                        break;
                    case 0:
                        Console.WriteLine("Thoat chuong trinh. Hen gap lai!");
                        break;
                    default:
                        Console.WriteLine("Lua chon khong hop le. Vui long thu lai.");
                        break;
                }
            } while (choice != 0);
        }
        static void PhanSo()
        {
            PhanSo ps1 = new PhanSo(1, 2);
            PhanSo ps2 = new PhanSo(1, 3);
            PhanSo ps3 = new PhanSo(2, 4);
            Console.Write("Phan so 1: ");
            ps1.Xuat();
            Console.Write("Phan so 2: ");
            ps2.Xuat();
            Console.Write("Phan so 3: ");
            ps3.Xuat();
            Console.Write("Cong: ");
            (ps1 + ps2).Xuat();
            Console.Write("Tru: ");
            (ps1 - ps2).Xuat();
            Console.Write("Nhan: ");
            (ps1 * ps2).Xuat();
            Console.Write("Chia: ");
            (ps1 / ps2).Xuat();
            Console.WriteLine($"> : {ps1 > ps2}");
            Console.WriteLine($"< : {ps1 < ps2}");
            Console.WriteLine($"== : {ps1 == ps3}");
            Console.WriteLine($"!= : {ps1 != ps3}");
        }
        static void Circle()
        {
            ListCircle listCircle = new ListCircle();
            listCircle.Nhap();
            Console.WriteLine("\n\nDanh sach cac hinh tron:");
            listCircle.OutPut_List();
            Console.WriteLine($"\n\nTong dien tich la: {listCircle.Sum_Area()}");
            Console.WriteLine("\n\nHinh tron co chu vi lon nhat la:");
            listCircle.Find_Max().Info();
        }
        static void HocPhan()
        {
            // Nhap vao 1 hoa don hoc phi
            HoaDonHocPhi hoaDon = new HoaDonHocPhi();
            hoaDon.NhapHoaDon();

            // In ra thong tin hoa don vua nhap
            Console.WriteLine("\nThong tin hoa don hoc phi vua nhap:");
            hoaDon.XuatHoaDon();

            // In ra tong so tin chi
            Console.WriteLine($"\nTong so tin chi: {hoaDon.TinhTongSoTinChi()}");
        }
        static void KhachSan()
        {
            QuanLyPhieuLuuTru quanLy = new QuanLyPhieuLuuTru();
            quanLy.NhapDanhSachPhieu();
            quanLy.XuatDanhSachPhieuTheoSoNgayO();
            quanLy.DemPhieuLuuTruQuy4Nam2024();
            quanLy.TinhVaInTienPhongTrungBinh();
        }
        static void Adult()
        {
            QuanLyNghiaVuQuanSu quanLy = new QuanLyNghiaVuQuanSu();
            quanLy.NhapDanhSachThanhNien();
            quanLy.HienThiDanhSachDuDieuKien();
        }
        static void HocVien()
        {
            QuanLyHocVien quanLy = new QuanLyHocVien();
            quanLy.NhapDanhSachHocVien();
            quanLy.XuatDanhSachHocVienTheoSoTietHoc();
            quanLy.TinhVaXuatTongHocPhi();
        }
    }
}
