﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_TruongThiBaoNhi
{
    class PhanSo
    {
        public int tu_so { get; set; }
        public int mau_so { get; set; }
        //khong co tham so
        public PhanSo()
        {
            tu_so = 0;
            mau_so = 1;
        }
        //co tham so
        public PhanSo(int gia_tri_tu_so, int gia_tri_mau_so)
        {
            tu_so = gia_tri_tu_so;
            mau_so = gia_tri_mau_so;
        }
        //sao chep
        public PhanSo(PhanSo ps)
        {
            tu_so = ps.tu_so;
            mau_so = ps.mau_so;
        }
        public static int TimUCLN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
        //Rut gon phan so
        public PhanSo RutGon()
        {
            int ucln = TimUCLN(this.tu_so, this.mau_so);
            this.tu_so /= ucln;
            this.mau_so /= ucln;
            return this;
        }
        //Toan tu +
        public static PhanSo operator +(PhanSo ps1, PhanSo ps2)
        {
            int tuSoMoi;
            int mauSoMoi;
            if (ps1.mau_so == ps2.mau_so)
            {
                tuSoMoi = ps1.tu_so + ps2.tu_so;
                mauSoMoi = ps1.mau_so;
            }
            else
            {
                tuSoMoi = ps1.tu_so * ps2.mau_so + ps2.tu_so * ps1.mau_so;
                mauSoMoi = ps1.mau_so * ps2.mau_so;
            }
            return new PhanSo(tuSoMoi, mauSoMoi).RutGon();
        }
        //Toan tu -
        public static PhanSo operator -(PhanSo ps1, PhanSo ps2)
        {
            int tuSoMoi;
            int mauSoMoi;
            if (ps1.mau_so == ps2.mau_so)
            {
                tuSoMoi = ps1.tu_so - ps2.tu_so;
                mauSoMoi = ps1.mau_so;
            }
            else
            {
                tuSoMoi = ps1.tu_so * ps2.mau_so - ps2.tu_so * ps1.mau_so;
                mauSoMoi = ps1.mau_so * ps2.mau_so;
            }
            return new PhanSo(tuSoMoi, mauSoMoi).RutGon();
        }
        //Toan tu *
        public static PhanSo operator *(PhanSo ps1, PhanSo ps2)
        {
            int tuSoMoi = ps1.tu_so * ps2.tu_so;
            int mauSoMoi = ps1.mau_so * ps2.mau_so;
            return new PhanSo(tuSoMoi, mauSoMoi).RutGon();
        }
        //Toan tu /
        public static PhanSo operator /(PhanSo ps1, PhanSo ps2)
        {
            int tuSoMoi = ps1.tu_so * ps2.mau_so;
            int mauSoMoi = ps1.mau_so * ps2.tu_so;
            return new PhanSo(tuSoMoi, mauSoMoi).RutGon();
        }
        //Toan tu >
        public static bool operator >(PhanSo ps1, PhanSo ps2)
        {
            return (double)ps1.tu_so / ps1.mau_so > (double)ps2.tu_so / ps2.mau_so;
        }
        //Toan tu <
        public static bool operator <(PhanSo ps1, PhanSo ps2)
        {
            return (double)ps1.tu_so / ps1.mau_so < (double)ps2.tu_so / ps2.mau_so;
        }
        //Toan tu ==
        public static bool operator ==(PhanSo ps1, PhanSo ps2)
        {
            if (ReferenceEquals(ps1, ps2))
            {
                return true;
            }
            if (ReferenceEquals(ps1, null) || ReferenceEquals(ps2, null))
            {
                return false;
            }
            PhanSo rutGon1 = new PhanSo(ps1.tu_so, ps1.mau_so).RutGon();
            PhanSo rutGon2 = new PhanSo(ps2.tu_so, ps2.mau_so).RutGon();
            return rutGon1.tu_so == rutGon2.tu_so && rutGon1.mau_so == rutGon2.mau_so;
        }
        //Toan tu !=
        public static bool operator !=(PhanSo ps1, PhanSo ps2)
        {
            return !(ps1 == ps2);
        }
        public void Xuat()
        {
            Console.WriteLine($"{tu_so}/{mau_so}");
        }

    }
}
