﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_TruongThiBaoNhi
{
    class HocPhan
    {
        //khai bao thuoc tinh
        public string ma_hoc_phan;
        public string ten_hoc_phan;
        public byte sotc;
        public bool dai_cuong;
        //khoi tao khong tham so
        public HocPhan()
        {
            ma_hoc_phan = "";
            ten_hoc_phan = "";
            sotc = 0;
            dai_cuong = true;
        }
        // khoi tao co tham so
        public HocPhan(string mhp, string thp, byte stc, bool dc)
        {
            ma_hoc_phan = mhp;
            ten_hoc_phan = thp;
            sotc = stc;
            dai_cuong = dc;
        }
        //nhap thong tin hoc phan
        public void Nhap()
        {
            Console.Write("Nhap ma hoc phan: ");
            ma_hoc_phan = Console.ReadLine();
            Console.Write("Nhap ten hoc phan: ");
            ten_hoc_phan = Console.ReadLine();
            Console.Write("Nhap so tin chi: ");
            while (!byte.TryParse(Console.ReadLine(), out sotc) || sotc <= 0 || sotc > 10)
            {
                Console.Write("Nhap lai le len!!!!!!!!");
            }
            Console.Write("Chuyen nganh hay dai cuong ?:  (true/false)");
            while (!bool.TryParse(Console.ReadLine(), out dai_cuong))
            {
                Console.Write("Nhap lai le len!!!!!!!!");
            }   
        }
        //tinh hoc phi
        public int TinhHP()
        {
            if (true)
            {
                return sotc * 550;
            }    
            else
            {
                return sotc * 310;
            }    
        }
        //Xuat thong tin
        public void Xuat()
        {
            Nhap();
            Console.WriteLine($"Tien hoc phi: {TinhHP()}");
        }
        //toan tu + 1 so nguyen voi 1 doi tuong hoc phi
        public static int operator + (int n, HocPhan hp)
        {
            return n + hp;
        }
        //toan tu so sanh
        public static bool operator < (HocPhan hp1, HocPhan hp2)
        {
            return hp1.TinhHP() < hp2.TinhHP();
        }
        public static bool operator > (HocPhan hp1, HocPhan hp2)
        {
            return hp1.TinhHP() > hp2.TinhHP();
        }
    }
    //hoa don hoc phi
    class HoaDonHocPhi
    {
        //khai bao thuoc tinh
        public string ma_so_sinh_vien;
        public string ho_ten;
        public HocPhan[] ds;
        //khoi tao khong co tham so
        public HoaDonHocPhi()
        {
            ma_so_sinh_vien = "";
            ho_ten = "";
            ds = new HocPhan[0];
        }
        //khoi tao co tham so
        public HoaDonHocPhi(string mssv, string hoten, HocPhan[] list)
        {
            ma_so_sinh_vien = mssv;
            ho_ten = hoten;
            ds = list;
        }
        //nhap thong tin hoa don hoc phi
        public void NhapHoaDon()
        {
            Console.Write("Nhap ma so sinh vien: ");
            ma_so_sinh_vien = Console.ReadLine();
            Console.Write("Nhap ho va ten: ");
            ho_ten = Console.ReadLine();
            int so_luong_hoc_phan;
            do
            {
                Console.Write("Nhap so luong hoc phan (2-9): ");
                if (!int.TryParse(Console.ReadLine(), out so_luong_hoc_phan) || so_luong_hoc_phan < 2 || so_luong_hoc_phan > 9)
                {
                    Console.WriteLine("So luong hoc phan khong hop le. Vui long nhap lai.");
                }
                else
                {
                    break;
                }
            } while (true);

            ds = new HocPhan[so_luong_hoc_phan];
            for (int i = 0; i < so_luong_hoc_phan; i++)
            {
                Console.WriteLine($"Nhap thong tin hoc phan {i + 1}:");
                ds[i] = new HocPhan();
                ds[i].Nhap();
            }
        }
        public int TinhTongSoTinChi()
        {
            int tong_so_tc = 0;
            foreach (HocPhan hp in ds)
            {
                tong_so_tc += hp.sotc;
            }
            return tong_so_tc;
        }
        //tinh tong hoc phi
        public int TinhTongHocPhi()
        {
            int tong_hoc_phi = 0;
            foreach (HocPhan hp in ds)
            {
                tong_hoc_phi += hp.TinhHP();
            }
            return tong_hoc_phi;
        }
        //xuat thong tin hoa don hoc phi
        public void XuatHoaDon()
        {
            Console.WriteLine("------------------ HOA DON HOC PHI ------------------");
            Console.WriteLine($"Ma so sinh vien: {ma_so_sinh_vien}");
            Console.WriteLine($"Ho va ten: {ho_ten}");
            Console.WriteLine("Danh sach hoc phan:");
            //sap xep theo thu tu giam dan cua so tin chi
            Array.Sort(ds, (hp1, hp2) => hp2.sotc.CompareTo(hp1.sotc));
            foreach (HocPhan hp in ds)
            {
                hp.Xuat();
            }
            Console.WriteLine($"Tong so tin chi: {TinhTongSoTinChi()}");
            Console.WriteLine($"Tong tien hoc phi: {TinhTongHocPhi()}");
            Console.WriteLine("-----------------------------------------------------");
        }
    }
}
