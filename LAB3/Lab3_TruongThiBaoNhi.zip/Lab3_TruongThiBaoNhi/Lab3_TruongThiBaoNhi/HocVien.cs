﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_TruongThiBaoNhi
{
    class HocVien
    {
        // Các thuộc tính
        public string maHocVien { get; set; }
        public string hoTen { get; set; }
        public string lopHoc { get; set; } // A, B, C
        public int soTietHoc { get; set; }
        public static int hocPhiMotTiet = 100; // Học phí 1 tiết học dùng chung

        // Các phương thức

        // Khởi tạo không tham số
        public HocVien()
        {
            maHocVien = "";
            hoTen = "";
            lopHoc = "";
            soTietHoc = 0;
        }

        // Khởi tạo có tham số
        public HocVien(string maHV, string ten, string lop, int tietHoc)
        {
            maHocVien = maHV;
            hoTen = ten;
            lopHoc = lop;
            soTietHoc = tietHoc;
        }

        // Nhập thông tin cho học viên
        public void NhapThongTin()
        {
            Console.Write("Nhap ma hoc vien: ");
            maHocVien = Console.ReadLine();
            Console.Write("Nhap ho ten hoc vien: ");
            hoTen = Console.ReadLine();
            Console.Write("Nhap lop hoc (A, B, C): ");
            lopHoc = Console.ReadLine();
            Console.Write("Nhap so tiet hoc: ");
            soTietHoc = int.Parse(Console.ReadLine());
        }

        // Tính tiền học phí phải đóng
        public double TinhHocPhi()
        {
            double tienGiam = 0;
            if (soTietHoc > 50)
            {
                tienGiam = 0.1 * (soTietHoc * hocPhiMotTiet);
            }
            else if (soTietHoc > 30)
            {
                tienGiam = 0.07 * (soTietHoc * hocPhiMotTiet);
            }
            return soTietHoc * hocPhiMotTiet - tienGiam;
        }

        // Xuất thông tin học viên
        public void XuatThongTin()
        {
            Console.WriteLine($"Ma HV: {maHocVien}, Ten: {hoTen}, Lop: {lopHoc}, Tiet hoc: {soTietHoc}, Hoc phi: {TinhHocPhi()}");
        }

        // Các toán tử

        // Toán tử so sánh > (so sánh số tiết học)
        public static bool operator >(HocVien hv1, HocVien hv2)
        {
            return hv1.soTietHoc > hv2.soTietHoc;
        }

        public static bool operator <(HocVien hv1, HocVien hv2)
        {
            return hv1.soTietHoc < hv2.soTietHoc;
        }

        // Toán tử + (cộng tiền học phí học viên với một số)
        public static double operator +(double tien, HocVien hv)
        {
            return tien + hv.TinhHocPhi();
        }
    }

    class QuanLyHocVien
    {
        private List<HocVien> danhSachHocVien;

        public QuanLyHocVien()
        {
            danhSachHocVien = new List<HocVien>();
        }

        public void NhapDanhSachHocVien()
        {
            int n;
            Console.Write("Nhap so luong hoc vien (2 < n < 30): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 2 || n >= 30)
            {
                Console.Write("Nhap lai (2 < n < 30): ");
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nNhap thong tin hoc vien thu {i + 1}:");
                HocVien hv = new HocVien();
                hv.NhapThongTin();
                danhSachHocVien.Add(hv);
            }
        }

        public void XuatDanhSachHocVienTheoSoTietHoc()
        {
            Console.WriteLine("\n\nDanh sach hoc vien (tang dan theo so tiet hoc):");
            danhSachHocVien.Sort((hv1, hv2) => hv1.soTietHoc.CompareTo(hv2.soTietHoc));
            foreach (HocVien hv in danhSachHocVien)
            {
                hv.XuatThongTin();
                Console.WriteLine("--------------------");
            }
        }

        public void TinhVaXuatTongHocPhi()
        {
            double tongHocPhi = 0;
            foreach (HocVien hv in danhSachHocVien)
            {
                tongHocPhi = tongHocPhi + hv; // Sử dụng toán tử +
            }
            Console.WriteLine($"\n\nTong hoc phi cua {danhSachHocVien.Count} hoc vien la: {tongHocPhi}");
        }
    }
}