﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_TruongThiBaoNhi
{
    class Adult
    {
        public string name { get; set; }
        public int age { get; set; }
        public string gender { get; set; }
        public string address { get; set; }
        public string health { get; set; }

        public Adult()
        {
            name = "";
            age = 18;
            gender = "Unknown";
            address = "";
            health = "";
        }

        public Adult(string name, int age, string gender, string address, string health)
        {
            this.name = name;
            this.age = age;
            this.gender = gender;
            this.address = address;
            this.health = health;
        }

        public void Input()
        {
            Console.Write("Nhap ten: ");
            name = Console.ReadLine();
            Console.Write("Nhap tuoi: ");
            age = int.Parse(Console.ReadLine());
            Console.Write("Nhap gioi tinh: ");
            gender = Console.ReadLine();
            Console.Write("Nhap dia chi: ");
            address = Console.ReadLine();
            Console.Write("Nhap tinh trang suc khoe (Tot, Trung Binh, Kem): ");
            health = Console.ReadLine();
        }

        public void Output()
        {
            Console.WriteLine($"Ten: {name}, Tuoi: {age}, Gioi tinh: {gender}, Dia chi: {address}, Suc khoe: {health}");
        }
    }

    class QuanLyNghiaVuQuanSu
    {
        private List<Adult> danhSachThanhNien;

        public QuanLyNghiaVuQuanSu()
        {
            danhSachThanhNien = new List<Adult>();
        }

        public void NhapDanhSachThanhNien()
        {
            int n;
            Console.Write("Nhap so luong thanh nien (2 < n < 100): ");
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 2 || n >= 100)
            {
                Console.Write("Nhap lai (2 < n < 100): ");
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nNhap thong tin thanh nien thu {i + 1}:");
                Adult thanhNien = new Adult();
                thanhNien.Input();
                danhSachThanhNien.Add(thanhNien);
            }
        }

        public void HienThiDanhSachDuDieuKien()
        {
            Console.WriteLine("\n\nDanh sach thanh nien du dieu kien suc khoe (Tot):");
            foreach (Adult thanhNien in danhSachThanhNien)
            {
                if (thanhNien.health.ToLower() == "tot")
                {
                    thanhNien.Output();
                }
            }
        }
    }
}