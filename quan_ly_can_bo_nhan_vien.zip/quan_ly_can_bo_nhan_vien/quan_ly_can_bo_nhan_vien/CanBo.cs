﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quan_ly_can_bo_nhan_vien
{
    //lop co so = lop cha
    class CanBo
    {
        //khai bao thuoc tinh
        public string ma_so;
        public string ho_ten;
        public bool gioi_tinh;
        //khoi tao khong co tham so
        public CanBo()
        {
            ma_so = "";
            ho_ten = "";
            gioi_tinh = true;
        }
        //khoi tao co tham so
        public CanBo(string MaSo, string HoTen, bool GT)
        {
            ma_so = MaSo;
            ho_ten = HoTen;
            gioi_tinh = GT;
        }
        //nhap thong tin can bo
        public virtual void NhapThongTinCanBo()
        {
            Console.Write("Nhap ma so: ");
            ma_so = Console.ReadLine();
            Console.Write("Nhap ho ten: ");
            ho_ten = Console.ReadLine();
            Console.Write("Gioi tinh (true/false): ");
            gioi_tinh = bool.Parse(Console.ReadLine());
        }
        //in thong tin can bo
        public virtual void InThongTinCanBo()
        {
            Console.WriteLine("Ma so: " + ma_so);
            Console.WriteLine("Ho ten: " + ho_ten);
            if (gioi_tinh)
                Console.WriteLine("Nam");
            else
                Console.WriteLine("Nu");
        }
    }
    //lop dan xuat = lop con
    class NVHC : CanBo
    {
        //khai bao thuoc tinh
        public double ngay_cong;
        public double luong_thang;
        //khoi tao khong tham so
        public NVHC()
        {
            ngay_cong = 0;
            luong_thang = 0;
        }
        //khoi tao co tham so
        public NVHC(double ngay_cong, double luong_thang)
        {
            this.ngay_cong = ngay_cong;
            this.luong_thang = luong_thang;
        }
        //nhap luong
        public void NhapThongTinLuong()
        {
            Console.Write("Nhap so ngay cong: ");
            ngay_cong = double.Parse(Console.ReadLine());
            Console.Write("Nhap luong thang: ");
            luong_thang = double.Parse(Console.ReadLine());
        }
        //tinh tien luong
        public double TienLuong()
        {
            return (ngay_cong * luong_thang) / 26;
        }
        //in luong
        public void InThongTinLUong()
        {
            Console.WriteLine($"So ngay cong: {ngay_cong}");
            Console.WriteLine($"Luong thang: {luong_thang}");
            Console.WriteLine($"Tien luong: {TienLuong()}");
        }
        //ghi de thong tin len nhap thong tin nv
        public override void NhapThongTinCanBo()
        {
            base.NhapThongTinCanBo();
            NhapThongTinLuong();
        }
        //ghi de thong tin len len in thong tin nv
        public override void InThongTinCanBo()
        {
            base.InThongTinCanBo();
            InThongTinLUong();
        }
    }
    //lop dan xuat = lop con
    class GV : CanBo
    {
        //khai bao
        public int so_tiet;
        public int thu_lao_1_tiet;
        //khoi tao khong tham so
        public GV()
        {
            so_tiet = 0;
            thu_lao_1_tiet = 0;
        }
        //khoi tao co tham so
        public GV(int SoTiet, int ThuLao1Tiet)
        {
            so_tiet = SoTiet;
            thu_lao_1_tiet = ThuLao1Tiet;
        }
        //nhap thong tin thu lao
        public virtual void NhapThongTinThuLao()
        {
            Console.Write("Nhap so tiet: ");
            so_tiet = int.Parse(Console.ReadLine());
            Console.Write("Nhap muc thu lao 1 tiet: ");
            thu_lao_1_tiet = int.Parse(Console.ReadLine());
        }
        //tinh thu lao
        public int TinhThulao()
        {
            return so_tiet * thu_lao_1_tiet;
        }
        //in thong tin thu lao
        public virtual void InThongTinThuLao()
        {
            Console.WriteLine($"So tiet: {so_tiet}");
            Console.WriteLine($"Muc thu lao 1 tiet: {thu_lao_1_tiet}");
            Console.WriteLine($"Thu lao: {TinhThulao()}");
        }
        //ghi de len nhap thong tin can bo
        public override void NhapThongTinCanBo()
        {
            base.NhapThongTinCanBo();
            NhapThongTinThuLao();
        }
        //ghi de len in thong tin can bo
        public override void InThongTinCanBo()
        {
            base.InThongTinCanBo();
            InThongTinThuLao();
        }
    }
}
