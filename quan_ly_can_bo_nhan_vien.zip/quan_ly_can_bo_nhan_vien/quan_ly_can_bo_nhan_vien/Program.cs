﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quan_ly_can_bo_nhan_vien
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Can bo hay Giang vien (true/false): ");
            bool chon = bool.Parse(Console.ReadLine());
            if (chon == true)
            {
                NVHC nv = new NVHC();
                nv.NhapThongTinCanBo();
                nv.InThongTinCanBo();
            }
            else
            {
                GV gv = new GV();
                gv.NhapThongTinCanBo();
                gv.InThongTinCanBo();
            }
        }
    }
}
